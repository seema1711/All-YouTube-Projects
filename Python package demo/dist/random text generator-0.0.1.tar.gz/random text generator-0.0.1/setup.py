import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="random text generator", # Replace with your own username
    version="0.0.1",
    author="Seema Saharan",
    description="It is a random text generator.",
    python_requires='>=3.6'
)